USE TestDb1;
alter table your_table rename to my_table;